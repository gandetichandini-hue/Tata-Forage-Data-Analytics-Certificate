# Power BI Sales Dashboard
Upload your PBIX file here.
Sample dataset included.