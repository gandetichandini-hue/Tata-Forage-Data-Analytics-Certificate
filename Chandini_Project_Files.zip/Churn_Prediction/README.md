# Churn Prediction
Basic logistic regression model.