CREATE TABLE sales(id INT, product VARCHAR(50), quantity INT, price INT);
SELECT product, SUM(quantity*price) AS total_revenue FROM sales GROUP BY product;